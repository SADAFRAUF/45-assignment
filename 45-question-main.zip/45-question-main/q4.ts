var famous_person = "Albert Einstein";
var message = "".concat(famous_person, " once said,A person who never made a mistake never tried anything new.");
console.log(message);