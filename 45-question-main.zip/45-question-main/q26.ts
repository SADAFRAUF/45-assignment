let alien_color = "pink";

// Green alien version:
// alien_color = "green";
// if (alien_color == "green") {
//   console.log("You earned 5 points.");
// } else if (alien_color == "yellow") {
//   console.log("You earned 10 points.");
// } else if (alien_color == "red") {
//   console.log("You earned 15 points.");
// }

// Yellow alien version:
// alien_color = "yellow";
// if (alien_color == "green") {
//   console.log("You earned 5 points.");
// } else if (alien_color == "yellow") {
//   console.log("You earned 10 points.");
// } else if (alien_color == "red") {
//   console.log("You earned 15 points.");
// }

// Red alien version:
alien_color = "red";
if (alien_color == "green") {
  console.log("You earned 5 points.");
} else if (alien_color == "yellow") {
  console.log("You earned 10 points.");
} else if (alien_color == "red") {
  console.log("You earned 15 points.");
}

export {} // To prevent errors from redeclaration