let car = "subaru";
//console.log("Is car == 'subaru'?  predict true");
//console.log(car == "subaru");
console.log("Is car == 'Subaru'?  predict false");
console.log(car == "Subaru");
export {};
