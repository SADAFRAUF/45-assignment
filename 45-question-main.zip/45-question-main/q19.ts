let countries: string[] = ["Japan", "Canada", "New Zealand", "Iceland", "Switzerland"];
console.log("Countries I'd like to visit:", countries);

let mountains:string[] = ["Himalayas","K-2","Nanga Parbat"];
console.log("These Mountainous areas I'd like to visit:" ,mountains);