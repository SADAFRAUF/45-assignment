// Sadaf Rauf, 2024-04-13
// This program prints a personal message.
let myName = "Sadaf Rauf";
console.log(`Hello ${myName}, would you like to learn some TS today?`);
export {};
