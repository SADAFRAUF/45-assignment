var myName = "\t\n Sadaf \t\n"; 
console.log(myName); 
console.log(myName.trim()); 