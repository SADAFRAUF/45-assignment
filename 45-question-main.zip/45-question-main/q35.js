function make_shirt(size, message) {
    console.log(`Making a ${size} t-shirt with the message "${message}" printed on it`);
}
make_shirt("medium", "Code is Life");
export {};
