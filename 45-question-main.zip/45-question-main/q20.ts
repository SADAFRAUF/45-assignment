let book: { title: string; author: string; yearPublished: number } = {
    title: "The Great Book of Mercy",
    author: "Jabir Ibn Hayyan",
    yearPublished:925
};
console.log(`Book Info: ${book.title} by ${book.author}, published in ${book.yearPublished}`);