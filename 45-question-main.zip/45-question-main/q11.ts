let names: string[] = ["Laiba", "Malaika", "Riffat", "Saba"]; {
    console.log(`Hello ${names}, would you like to learn some TS today?`);
}