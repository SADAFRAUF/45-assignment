var myName = "Sadaf Rauf";

console.log ('Hello Sadaf Rauf', "would you like to learn some Python today?")