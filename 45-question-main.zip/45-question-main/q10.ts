let names : string[] = ["Laiba", "Malaika", "Riffat", "Saba"];
for (let i = 0; i < names.length; i++) {
    console.log(names[i]);
}