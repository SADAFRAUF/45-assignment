var favoriteNumber = 1;
console.log(`My favorite number is ${favoriteNumber}.`);
export {};
