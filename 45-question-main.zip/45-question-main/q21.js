let days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
//console.log(days{7})
console.log(days);
export {};
