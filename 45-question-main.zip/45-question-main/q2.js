var myName = "Sadaf Rauf";
console.log(myName.toLowerCase());
console.log(myName.toUpperCase());
console.log(myName.charAt(0).toUpperCase() + myName.slice(1).toLowerCase());
export {};
