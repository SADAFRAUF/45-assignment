let usernames: string[] = [];

if(usernames.length === 0){
    console.log("We need to find some users!");
    
} else {
    // Greet Users 
}

// Removing all usernames ensures the message "We need to find some users!" is printed.