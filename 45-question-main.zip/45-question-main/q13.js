let guests = ["Quaid-e-Azam", "Abdul Qadeer Khan", "Abdul Sattar Edhi", "Sir Kamran Khan Tessori", "Sir Zia"];
guests.forEach(guest => {
    console.log(`Dear ${guest}, would you like to join me for dinner?`);
});
export {};
