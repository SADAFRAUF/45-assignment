let transports: string[] = ["4WD", "Bugatti La Voiture Noire", "Scooty"];

transports.forEach(transport => {
    console.log(`I would like to own a ${transport}.`);
});