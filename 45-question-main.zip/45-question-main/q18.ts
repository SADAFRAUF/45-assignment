let guests: string[] = ["Sir Kamran","Sir Daniyal", "Sir Zia", "Sir Asharib", "Sir Ameen", "Sir Bilal"];
console.log(`I am inviting ${guests.length} people to dinner.`);