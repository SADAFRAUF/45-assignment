//const str1:string = 'Sadaf';
//const str2:string = 'Sadaf Rauf';
//console.log(str1 === str2);
//console.log(str1 !== str2);


//const text1:string = "Sadaf Rauf";
//const text2:string = "sadaf rauf";
//console.log(text1.toLowerCase() === text2);


// Numerical tests
//console.log("Numerical tests:");
//console.log(10 > 5); // True
//console.log(2 < 1); // False

// Tests using "and" and "or" operators
//console.log("Tests with 'and' and 'or':");
//console.log(true && false); // False
//console.log(true || false); // True

// Test whether an item is in a array
let fruits = ["apple", "banana", "cherry"];
//console.log("Is 'apple' in fruit?");
//console.log(fruits.includes("apple")); // True

// Test whether an item is not in a array
console.log("Is 'mango' in fruits?");
console.log(!fruits.includes ("mango")); // True