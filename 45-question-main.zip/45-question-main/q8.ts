var favoriteNumber: number = 1; 
console.log(`My favorite number is ${favoriteNumber}.`); 