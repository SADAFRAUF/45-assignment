let usernames = [];
if (usernames.length === 0) {
    console.log("We need to find some users!");
}
else {
    // Greet Users 
}
export {};
// Removing all usernames ensures the message "We need to find some users!" is printed.
